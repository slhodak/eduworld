#!/bin/bash

# Compress and archive the Eduworld project
# for uploading to the host server

